document.addEventListener('DOMContentLoaded', function() {
    const burgerIcon = document.querySelector('#burger-icon');
    const menu = document.getElementById('menu');

    burgerIcon.addEventListener('click', function() {
        menu.classList.toggle('active')
        for (const childbar of burgerIcon.children) {
            childbar.classList.toggle('bar-active')
        }        
    });
});